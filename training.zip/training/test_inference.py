"""
Eğitilmiş modeli, verilen test görüntüleri (etiketsiz stop_sign_data_set) üzerinde
çalıştırır; tespit kutuları çizilmiş görselleri kaydeder ve her görüntü için
tespit edilen kutu sayısı + confidence değerlerini yazdırır.

Kullanım (repo kök dizininden veya training/ klasöründen çalıştırılabilir):
    python training/test_inference.py --source path/to/stop_sign_data_set --conf 0.25
"""
import argparse
from pathlib import Path

from ultralytics import YOLO

REPO_ROOT = Path(__file__).resolve().parent.parent


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--weights", default=str(REPO_ROOT / "weights" / "best.pt"))
    parser.add_argument("--source", required=True, help="Test görüntülerinin bulunduğu klasör")
    parser.add_argument("--conf", type=float, default=0.25, help="Confidence (güven) eşiği")
    parser.add_argument("--out", default=str(REPO_ROOT / "test_images_output"))
    args = parser.parse_args()

    model = YOLO(args.weights)

    results = model.predict(
        source=args.source,
        conf=args.conf,
        save=True,
        project=args.out,
        name="predictions",
        exist_ok=True,
    )

    for r in results:
        n_boxes = len(r.boxes)
        confs = [round(float(c), 3) for c in r.boxes.conf] if n_boxes else []
        print(f"{r.path}: {n_boxes} tespit, confidence değerleri={confs}")


if __name__ == "__main__":
    main()
