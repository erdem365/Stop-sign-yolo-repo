"""
YOLOv8n modelini STOP tabelası veri seti üzerinde eğitir.

Kullanım (repo kök dizininden veya training/ klasöründen çalıştırılabilir):
    python training/train.py
    # veya
    cd training && python train.py
"""
from pathlib import Path

from ultralytics import YOLO

# Script'in kendi konumuna göre mutlak yol kullanılır; böylece komut hangi
# dizinden çalıştırılırsa çalıştırılsın veri seti doğru bulunur.
REPO_ROOT = Path(__file__).resolve().parent.parent
DATA_YAML = str(REPO_ROOT / "stop_sign_yolo_dataset" / "data.yaml")


def main() -> None:
    model = YOLO("yolov8n.pt")  # COCO üzerinde önceden eğitilmiş (pre-trained) nano model

    model.train(
        data=DATA_YAML,
        epochs=50,          # veri seti tamamının kaç kez görüleceği
        imgsz=640,           # girdi görüntü boyutu (piksel)
        batch=8,              # her adımda işlenen görüntü sayısı
        optimizer="auto",     # kütüphane veri setine göre otomatik seçer (bu veri setinde AdamW seçildi)
        patience=20,          # 20 epoch boyunca iyileşme yoksa erken durdur
        seed=42,               # tekrarlanabilirlik için sabit tohum
        project=str(REPO_ROOT / "runs"),
        name="stop_sign_yolov8n",
        plots=True,            # eğitim/doğrulama grafiklerini otomatik üret
    )

    best_path = REPO_ROOT / "runs" / "stop_sign_yolov8n" / "weights" / "best.pt"
    print(f"Eğitim tamamlandı. Ağırlıklar: {best_path}")


if __name__ == "__main__":
    main()
